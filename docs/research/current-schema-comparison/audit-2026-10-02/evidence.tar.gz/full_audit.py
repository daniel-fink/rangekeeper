"""Independent per-case audit of the retained import-route probe."""
import concurrent.futures as futures
import hashlib,json,os,pathlib,subprocess,time,collections,sys
from jsonschema import FormatChecker
from jsonschema.validators import validator_for
root=pathlib.Path('/Volumes/Data/Projects/Rangekeeper')
base=pathlib.Path('/private/tmp/rk-probe-audit')
output=base/'full';output.mkdir(exist_ok=True)
cue='/private/tmp/rk-probe-audit-tools/cue'
schemas={};cases={}
for file in sorted((base/'captured').glob('*.json')):
 data=json.loads(file.read_text());schemas.update(data['schemas'])
 for key,row in data['cases'].items():
  if key in cases: assert cases[key]==row
  cases[key]=row
original=json.loads((root/'docs/research/current-schema-comparison/observed/results.json').read_text())
assert set(cases)=={x['identity'] for x in original}
for row in original:
 assert cases[row['identity']]['schema']==row['schema']
 assert cases[row['identity']]['accepted']==row['baseline']
print('All 713 original case identities and baseline outcomes reproduced.',flush=True)
validators={}
for key,schema in schemas.items():
 cls=validator_for(schema);cls.check_schema(schema)
 validators[key]=cls(schema,format_checker=FormatChecker())
# Recheck capture without monkey-patching and keep the actual rejection reasons.
for key,row in cases.items():
 errors=list(validators[row['schema']].iter_errors(row['document']))
 assert (not errors)==row['accepted'],key
 row['baseline_errors']=[dict(path=list(e.absolute_path),schema_path=list(e.absolute_schema_path),validator=e.validator,message=e.message) for e in errors]
print('All baseline outcomes independently verified with iter_errors.',flush=True)
def run(command,timeout):
 t=time.perf_counter()
 try:
  p=subprocess.run(command,text=True,capture_output=True,timeout=timeout)
  return dict(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.perf_counter()-t)
 except subprocess.TimeoutExpired as e:
  def decode(s):return s.decode(errors='replace') if isinstance(s,bytes) else s or ''
  return dict(returncode=None,stdout=decode(e.stdout),stderr=decode(e.stderr),seconds=time.perf_counter()-t)
imports={}
for key,schema in schemas.items():
 path=output/(key+'.schema.json');path.write_text(json.dumps(schema,indent=2)+'\n')
 r=run([cue,'import','jsonschema',str(path),'-p','comparison','-o',str(output/(key+'.cue'))],5)
 assert r['returncode']==0,(key,r)
 imports[key]=r
rows=[]
def check(item):
 key,row=item
 result=dict(identity=key,schema=row['schema'],baseline=row['accepted'],baseline_errors=row['baseline_errors'])
 try:encoded=json.dumps(row['document'],allow_nan=False)
 except ValueError:return dict(result,outcome='non_json_numeric_input')
 path=output/(key+'.case.json');path.write_text(encoded+'\n')
 r=run([cue,'vet','-c',str(output/(row['schema']+'.cue')),str(path)],5)
 result.update(r)
 if r['returncode'] is None:outcome='timeout'
 elif r['returncode'] not in (0,1):outcome='process_error'
 else:outcome='match' if (r['returncode']==0)==row['accepted'] else 'difference'
 return dict(result,outcome=outcome)
with (output/'results.jsonl').open('w') as log:
 with futures.ThreadPoolExecutor(max_workers=2) as pool:
  for row in pool.map(check,sorted(cases.items())):
   rows.append(row);log.write(json.dumps(row)+'\n');log.flush()
   if len(rows)%50==0:print(len(rows),dict(collections.Counter(x['outcome'] for x in rows)),flush=True)
(output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
summary=dict(case_count=len(cases),schema_count=len(schemas),workers=2,timeout_seconds=5,outcomes=dict(collections.Counter(x['outcome'] for x in rows)),imports=imports)
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(summary['outcomes'],flush=True)

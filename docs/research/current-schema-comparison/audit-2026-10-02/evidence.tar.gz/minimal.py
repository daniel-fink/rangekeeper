import json,pathlib,subprocess
from jsonschema import Draft201909Validator
base=pathlib.Path('/private/tmp/rk-probe-audit/minimal');base.mkdir(exist_ok=True)
cue='/private/tmp/rk-probe-audit-tools/cue'
pattern=r'^\S(?:[\s\S]*\S)?$(?![\s\S])'
experiments={
 'pattern':({'$schema':'https://json-schema.org/draft/2019-09/schema','type':'object','properties':{'code':{'type':'string','pattern':pattern}},'required':['code'],'additionalProperties':False},[{'code':s} for s in ['A','A B','',' ',' A','A ','A\n']]),
 'forbidden_optional':({'$schema':'https://json-schema.org/draft/2019-09/schema','type':'object','properties':{'kind':{'const':'entity'},'key':{'type':'string'}},'required':['kind'],'allOf':[{'not':{'required':['key']},'properties':{'key':{}}}],'additionalProperties':False},[{'kind':'entity'},{'kind':'entity','key':'foo'}]),
}
rows=[]
for name,(schema,cases) in experiments.items():
 sp=base/(name+'.schema.json');sp.write_text(json.dumps(schema,indent=2))
 cp=base/(name+'.cue');p=subprocess.run([cue,'import','jsonschema',str(sp),'-p','probe','-o',str(cp)],text=True,capture_output=True)
 assert p.returncode==0,p.stderr
 for i,case in enumerate(cases):
  dp=base/f'{name}-{i}.json';dp.write_text(json.dumps(case))
  p=subprocess.run([cue,'vet','-c',str(cp),str(dp)],text=True,capture_output=True,timeout=5)
  rows.append(dict(probe=name,document=case,baseline=Draft201909Validator(schema).is_valid(case),returncode=p.returncode,stderr=p.stderr))
# A small native control, not the complete native candidate.
native=base/'native-pattern.cue';native.write_text('package probe\ncode!: =~"^\\\\S(?:[\\\\s\\\\S]*\\\\S)?$"\n')
for i,case in enumerate(experiments['pattern'][1]):
 p=subprocess.run([cue,'vet','-c',str(native),str(base/f'pattern-{i}.json')],text=True,capture_output=True,timeout=5)
 rows.append(dict(probe='native-pattern',document=case,returncode=p.returncode,stderr=p.stderr))
(base/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(r['probe'],repr(r['document']),r.get('baseline'),r['returncode'],r['stderr'][:100].replace('\n',' | '))

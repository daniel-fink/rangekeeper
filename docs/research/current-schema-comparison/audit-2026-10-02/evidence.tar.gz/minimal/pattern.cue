package probe

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")

close({
	code!: string
})

package probe
code!: =~"^\\S(?:[\\s\\S]*\\S)?$"

package probe

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")

matchN(0, [null | bool | number | string | [...] | {
	key!: _
	...
}]) & {
	key?: _
	...
} & close({
	kind!: "entity"
	key?:  string
})

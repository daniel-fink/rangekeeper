import json,pathlib,subprocess,time,collections
base=pathlib.Path('/private/tmp/rk-probe-audit');rows=json.loads((base/'full/results.json').read_text());cue='/private/tmp/rk-probe-audit-tools/cue'
selected=[(r,5) for r in rows if r['outcome']=='difference']
for schema in sorted({r['schema'] for r in rows if r['outcome']=='timeout'}):
 selected.append((next(r for r in rows if r['schema']==schema and r['outcome']=='timeout' and r['baseline']),30))
results=[]
for r,limit in selected:
 t=time.monotonic()
 try:
  p=subprocess.run([cue,'vet','-c',str(base/'full'/(r['schema']+'.cue')),str(base/'full'/(r['identity']+'.case.json'))],text=True,capture_output=True,timeout=limit)
  result=dict(identity=r['identity'],schema=r['schema'],baseline=r['baseline'],original_outcome=r['outcome'],timeout_seconds=limit,returncode=p.returncode,stderr=p.stderr,seconds=time.monotonic()-t)
 except subprocess.TimeoutExpired:
  result=dict(identity=r['identity'],schema=r['schema'],baseline=r['baseline'],original_outcome=r['outcome'],timeout_seconds=limit,returncode=None,seconds=time.monotonic()-t)
 results.append(result)
 print(result['identity'],result['original_outcome'],result['returncode'],round(result['seconds'],2),flush=True)
(base/'confirmations.json').write_text(json.dumps(results,indent=2)+'\n')

// rangekeeper_query
//
// A non-executing query specification returning Entity or Value identities from
// the containing Model revision.
package comparison

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")
@jsonschema(id="https://daniel-fink.github.io/rangekeeper/schema/query")
close({
	duplicates!: #DuplicateHandling
	filter?: #Filter & matchN(>=1, [#Filter, null])
	projection!:  #Projection & #Projection
	starting_at!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Ordered traversal steps; omission selects the starting Entity.
	steps?: null | [...#Traversal & #Traversal]
})

// Assembly
//
// An Entity identifying a collection of Entities and Relationships. Members are
// referenced by identity and may belong to more than one Assembly. Membership
// does not imply spatial containment or duplicate its members.
#Assembly: close({
	// The Entity's labels and named values.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional case-sensitive code unique among all Entities and Assemblies in the
	// Model. Renaming it preserves UUID identity and references.
	code?: null | string

	// Unordered, unique UUIDs of member Entities, including nested Assemblies.
	entities?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Stable identity of the Entity, distinct from a Model revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable display name; not used as identity.
	name?: null | =~"\\S"

	// Unordered, unique UUIDs of member Relationships.
	relationships?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]
})

// Cardinality
#Cardinality: "one" | "many"

// Characteristics
//
// A collection of Labels and Values belonging to an Entity or Relationship.
// Each Label or Value has a stable UUID and a key unique within its
// collection.
#Characteristics: close({
	// Identified labels with explicit owner-local keys, unique within this collection.
	labels?: null | [...#Label]

	// Identified values with explicit owner-local keys, unique within this collection.
	values?: null | [...#Value]
})

// Classification
//
// A named definition node in a taxonomy hierarchy.
#Classification: close({
	// Case-sensitive code unique within its Taxonomy; descriptive metadata, not reference identity.
	code!: string

	// Optional explanatory text; an empty string is permitted.
	definition?: null | string

	// Stable identity across code changes and Model revisions.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name.
	name!: =~"\\S"

	// Parent Classification in the same Taxonomy, referenced by UUID. An absent or
	// null parent denotes a root candidate.
	parent?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Criterion
//
// Require an Entity Label with this owner-local key to include the exact Classification.
#Criterion: close({
	classification!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Owner-local Label key.
	key!: string & =~"\\S"
})

// Depth
#Depth: "direct" | "transitive"

// Direction
#Direction: "outgoing" | "incoming"

// DuplicateHandling
#DuplicateHandling: "distinct" | "preserve"

// Entity
//
// An identifiable domain object, such as an apartment, building, or actor. Its
// identity persists across immutable Model revisions. Loading its definition
// does not execute calculations.
#Entity: close({
	// The Entity's labels and named values.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional case-sensitive code unique among all Entities and Assemblies in the
	// Model. Renaming it preserves UUID identity and references.
	code?: null | string

	// Stable identity of the Entity, distinct from a Model revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable display name; not used as identity.
	name?: null | =~"\\S"
})

// Filter
//
// Conjunctive filters over fixed Entity metadata. No numerical expression or
// solved amount determines membership.
#Filter: close({
	classification?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// All listed Label conditions must hold.
	labels?: null | [...#Criterion & #Criterion]
})

// Label
//
// A named set of Classifications describing an aspect of an Entity or Relationship.
#Label: close({
	// Unique UUID references to Classifications describing this aspect.
	classifications?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Stable identity of the Label, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Name unique within the owner's characteristics.labels collection.
	key!: =~"\\S"
})

// Measure
//
// An identified definition of a measurable characteristic and its canonical units.
#Measure: close({
	// Case-sensitive code unique within the Model’s Measure collection; not reference identity.
	code!: string

	// Optional explanatory text describing the measurement convention.
	definition?: null | string

	// Stable identity of this Measure definition.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name of the measured characteristic.
	name!: =~"\\S"

	// Unordered, nonblank descriptive terms, with no duplicates.
	tags?: null | [...=~"\\S"]

	// Nonblank expression specifying the canonical units for quantities interpreted
	// through this Measure, such as m^2 or AUD/year. Unitless quantities must have
	// an explicit dimensionless convention.
	units!: =~"\\S"
})

// Measurement
//
// An identified measurable property with a Measure and an optional Quantity.
#Measurement: close({
	// Stable identity of the Measurement, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// Metadata
//
// Identity, description, and optional lineage of one immutable document revision.
#Metadata: close({
	// Optional explanation of this revision and its purpose.
	description?: null | string

	// UUID identifying the enclosing immutable document revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional human-readable name of this revision.
	name?: null | =~"\\S"

	// UUID of the preceding revision of the same document kind, referencing its Metadata.
	previous?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Version of the enclosing document's schema contract.
	schema_version!: string
})

// MissingHandling
#MissingHandling: "error" | "omit"

// Projection
//
// Select Entity identities or Values belonging to each matching Entity.
#Projection: matchN(2, [matchIf({
	kind!: "entity"
	...
}, matchN(4, [matchN(0, [null | bool | number | string | [...] | {
	key!: _
	...
}]) & {
	key?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	measure!: _
	...
}]) & {
	measure?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	cardinality!: _
	...
}]) & {
	cardinality?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	missing!: _
	...
}]) & {
	missing?: _
	...
}]), _) & {
	...
}, matchIf({
	kind!: "value"
	...
}, matchN(1, [{
	key!: _
	...
}, {
	measure!: _
	...
}]) & {
	cardinality!: _
	missing!:     _
	...
}, _) & {
	...
}]) & close({
	cardinality?: #Cardinality

	// Exact owner-local Value key.
	key?:  string & =~"\\S"
	kind!: #ProjectionKind

	// Select Values with this exact Measure.
	measure?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	missing?: #MissingHandling
})

// ProjectionKind
#ProjectionKind: "entity" | "value"

// Quantity
//
// Numerical content consisting of a finite magnitude and explicit units.
#Quantity: close({
	// Finite numerical magnitude expressed in the accompanying units.
	magnitude!: number

	// Explicit units for this magnitude, such as m^2, AUD/year, or dimensionless.
	units!: =~"\\S"
})

// Query
//
// A non-executing query specification returning Entity or Value identities from
// the containing Model revision.
#Query: close({
	duplicates!: #DuplicateHandling
	filter?: #Filter & matchN(>=1, [#Filter, null])
	projection!:  #Projection & #Projection
	starting_at!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Ordered traversal steps; omission selects the starting Entity.
	steps?: null | [...#Traversal & #Traversal]
})

// Relationship
//
// An identified, directed connection from one Entity to another. Its
// classification describes the connection; its characteristics describe
// properties of the connection itself.
#Relationship: close({
	// Labels and Values describing this connection.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Stable identity of the Relationship across Model revisions.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// UUID of the source Entity.
	source!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// UUID of the target Entity.
	target!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Taxonomy
//
// A named, single-root hierarchy of Classifications.
#Taxonomy: close({
	// Identified Classifications belonging to this Taxonomy; codes are unique within the collection.
	classifications!: [...#Classification] & [_, ...]

	// Case-sensitive code unique in the Model's taxonomy catalogue.
	code!:       string
	definition?: null | string
	id!:         =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	name!:       =~"\\S"
})

// Traversal
//
// One traversal step over domain Relationships or Assembly membership.
#Traversal: matchN(2, [matchIf({
	kind!: "relationship"
	...
}, {
	classification!: _
	direction!:      _
	...
}, _) & {
	...
}, matchIf({
	kind!: "membership"
	...
}, matchN(2, [matchN(0, [null | bool | number | string | [...] | {
	classification!: _
	...
}]) & {
	classification?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	direction!: _
	...
}]) & {
	direction?: _
	...
}]), _) & {
	...
}]) & close({
	// Exact Classification of Relationships to follow.
	classification?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	depth!:          #Depth
	direction?:      #Direction
	kind!:           #TraversalKind
})

// TraversalKind
#TraversalKind: "relationship" | "membership"

// Value
//
// An identified, typed Value belonging to an Entity or Relationship's
// Characteristics, or declared locally within a mathematical Formulation. Its
// key provides a name within the owner's values collection; its UUID
// identifies the symbol independently of that name.
#Value: close({
	// Explanation of the meaning of this Value within its owner.
	description?: null | string

	// Stable identity of the Value, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank name unique within the owner's values collection; not reference identity.
	key!: =~"\\S"

	// The kind of content represented by this characteristic.
	kind!: #ValueKind

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// ValueKind
//
// Supported kinds of Values.
#ValueKind: "measurement"

// rangekeeper_expression
//
// An identified mathematical expression. Its kind determines its content;
// nested expressions retain order and UUID references resolve in the
// applicable Model or composed Specification scope.
package comparison

import "list"

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")
@jsonschema(id="https://daniel-fink.github.io/rangekeeper/schema/expression")
matchN(9, [matchIf({
	kind!: "quantity"
	...
}, {
	quantity!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "boolean"
	...
}, {
	boolean!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "reference"
	...
}, {
	target!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "unary"
	...
}, {
	operand!:  _
	operator!: "negate" | "logical_not"
	...
}, _) & {
	...
}, matchIf({
	kind!: "binary"
	...
}, {
	operands!: [...]
	operator!: "add" | "subtract" | "multiply" | "divide" | "equal" | "not_equal" | "less_than" | "less_than_or_equal" | "greater_than" | "greater_than_or_equal" | "power" | "logical_and" | "logical_or"
	...
}, _) & {
	...
}, matchIf({
	kind!: "call"
	...
}, {
	call!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "selection"
	...
}, {
	selection!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "query"
	...
}, {
	query!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "quantity" | "boolean" | "reference" | "call" | "selection" | "query"
	...
}, matchN(0, [null | bool | number | string | [...] | {
	operator!: _
	...
}]) & {
	operator?: _
	...
}, _) & {
	...
}]) & matchN(1, [{
	quantity!: _
	...
}, {
	boolean!: _
	...
}, {
	target!: _
	...
}, {
	operand!: _
	...
}, {
	operands!: [...]
	...
}, {
	call!: _
	...
}, {
	selection!: _
	...
}, {
	query!: _
	...
}]) & close({
	// Boolean literal; false is a literal, not absence.
	boolean?: bool & bool
	call?: #Call & matchN(>=1, [#Call, null])

	// Stable identity of this Expression across Model revisions.
	id!:   =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	kind!: #ExpressionKind

	// Operand of unary negation or Boolean negation.
	operand?: #Expression & matchN(>=1, [#Expression, null])

	// Two ordered operands of a binary operator. Unary operators use operand;
	// Function calls use their own signature.
	operands?: null | list.MaxItems(2) & [...#Expression & #Expression] & [_, _, ...]
	operator?: #Operator

	// Numerical literal with an explicit magnitude and units, independent of any
	// Measure. Use dimensionless for unitless content. Zero is a literal, not
	// absence.
	quantity?: #Quantity & matchN(>=1, [#Quantity, null])
	query?: #Query & matchN(>=1, [#Query, null])
	selection?: #Selection & matchN(>=1, [#Selection, null])

	// Value symbol referenced by its stable UUID in the applicable Model or
	// composed Specification scope.
	target?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Argument
//
// One named expression argument in a Function call.
#Argument: close({
	expression!: #Expression & #Expression
	name!:       string
})

// Assembly
//
// An Entity identifying a collection of Entities and Relationships. Members are
// referenced by identity and may belong to more than one Assembly. Membership
// does not imply spatial containment or duplicate its members.
#Assembly: close({
	// The Entity's labels and named values.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional case-sensitive code unique among all Entities and Assemblies in the
	// Model. Renaming it preserves UUID identity and references.
	code?: null | string

	// Unordered, unique UUIDs of member Entities, including nested Assemblies.
	entities?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Stable identity of the Entity, distinct from a Model revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable display name; not used as identity.
	name?: null | =~"\\S"

	// Unordered, unique UUIDs of member Relationships.
	relationships?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]
})

// Call
//
// Application of an identified Function to positional and named expression arguments.
#Call: close({
	// Positional arguments, in order.
	arguments?: null | [...#Expression & #Expression]
	function!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Named arguments with unique parameter names. Their order is retained for
	// authoring, not positional binding.
	named_arguments?: null | [...#Argument & #Argument]
})

// Cardinality
#Cardinality: "one" | "many"

// Characteristics
//
// A collection of Labels and Values belonging to an Entity or Relationship.
// Each Label or Value has a stable UUID and a key unique within its
// collection.
#Characteristics: close({
	// Identified labels with explicit owner-local keys, unique within this collection.
	labels?: null | [...#Label]

	// Identified values with explicit owner-local keys, unique within this collection.
	values?: null | [...#Value]
})

// Classification
//
// A named definition node in a taxonomy hierarchy.
#Classification: close({
	// Case-sensitive code unique within its Taxonomy; descriptive metadata, not reference identity.
	code!: string

	// Optional explanatory text; an empty string is permitted.
	definition?: null | string

	// Stable identity across code changes and Model revisions.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name.
	name!: =~"\\S"

	// Parent Classification in the same Taxonomy, referenced by UUID. An absent or
	// null parent denotes a root candidate.
	parent?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// CollectionKind
#CollectionKind: "set" | "bag" | "sequence"

// Criterion
//
// Require an Entity Label with this owner-local key to include the exact Classification.
#Criterion: close({
	classification!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Owner-local Label key.
	key!: string & =~"\\S"
})

// Depth
#Depth: "direct" | "transitive"

// Direction
#Direction: "outgoing" | "incoming"

// Domain
//
// The permitted content of an argument or result, including its kind,
// compatible units, measurement meaning, and collection elements where
// applicable.
#Domain: matchN(4, [matchIf({
	kind!: "collection"
	...
}, {
	item_domain!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "number" | "quantity" | "measurement" | "boolean" | "string" | "date" | "span" | "flow" | "stream" | "account" | "entity"
	...
}, matchN(2, [matchN(0, [null | bool | number | string | [...] | {
	item_domain!: _
	...
}]) & {
	item_domain?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	collection_kind!: _
	...
}]) & {
	collection_kind?: _
	...
}]), _) & {
	...
}, matchIf({
	kind!: "number" | "quantity" | "boolean" | "string" | "date" | "span" | "stream" | "account" | "entity" | "collection"
	...
}, matchN(0, [null | bool | number | string | [...] | {
	measure!: _
	...
}]) & {
	measure?: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "number" | "measurement" | "boolean" | "string" | "date" | "span" | "flow" | "stream" | "account" | "entity" | "collection"
	...
}, matchN(0, [null | bool | number | string | [...] | {
	units!: _
	...
}]) & {
	units?: _
	...
}, _) & {
	...
}]) & close({
	// Optional collection shape required by this signature.
	collection_kind?: #CollectionKind

	// Domain of each collection element.
	item_domain?: #Domain & matchN(>=1, [#Domain, null])

	// The category of content permitted by this Domain.
	kind!: #DomainKind

	// Optional exact measurement meaning required for a measurement or Flow.
	measure?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional compatible units required for Quantity content. Omission leaves
	// units unconstrained by the signature; a concrete Quantity still requires
	// explicit units.
	units?: null | =~"\\S"
})

// DomainKind
#DomainKind: "number" | "quantity" | "measurement" | "boolean" | "string" | "date" | "span" | "flow" | "stream" | "account" | "entity" | "collection"

// DuplicateHandling
#DuplicateHandling: "distinct" | "preserve"

// EmptyHandling
#EmptyHandling: "error" | "zero"

// Entity
//
// An identifiable domain object, such as an apartment, building, or actor. Its
// identity persists across immutable Model revisions. Loading its definition
// does not execute calculations.
#Entity: close({
	// The Entity's labels and named values.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional case-sensitive code unique among all Entities and Assemblies in the
	// Model. Renaming it preserves UUID identity and references.
	code?: null | string

	// Stable identity of the Entity, distinct from a Model revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable display name; not used as identity.
	name?: null | =~"\\S"
})

// Expression
//
// An identified mathematical expression. Its kind determines its content;
// nested expressions retain order and UUID references resolve in the
// applicable Model or composed Specification scope.
#Expression: matchN(9, [matchIf({
	kind!: "quantity"
	...
}, {
	quantity!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "boolean"
	...
}, {
	boolean!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "reference"
	...
}, {
	target!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "unary"
	...
}, {
	operand!:  _
	operator!: "negate" | "logical_not"
	...
}, _) & {
	...
}, matchIf({
	kind!: "binary"
	...
}, {
	operands!: [...]
	operator!: "add" | "subtract" | "multiply" | "divide" | "equal" | "not_equal" | "less_than" | "less_than_or_equal" | "greater_than" | "greater_than_or_equal" | "power" | "logical_and" | "logical_or"
	...
}, _) & {
	...
}, matchIf({
	kind!: "call"
	...
}, {
	call!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "selection"
	...
}, {
	selection!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "query"
	...
}, {
	query!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "quantity" | "boolean" | "reference" | "call" | "selection" | "query"
	...
}, matchN(0, [null | bool | number | string | [...] | {
	operator!: _
	...
}]) & {
	operator?: _
	...
}, _) & {
	...
}]) & matchN(1, [{
	quantity!: _
	...
}, {
	boolean!: _
	...
}, {
	target!: _
	...
}, {
	operand!: _
	...
}, {
	operands!: [...]
	...
}, {
	call!: _
	...
}, {
	selection!: _
	...
}, {
	query!: _
	...
}]) & close({
	// Boolean literal; false is a literal, not absence.
	boolean?: bool & bool
	call?: #Call & matchN(>=1, [#Call, null])

	// Stable identity of this Expression across Model revisions.
	id!:   =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	kind!: #ExpressionKind

	// Operand of unary negation or Boolean negation.
	operand?: #Expression & matchN(>=1, [#Expression, null])

	// Two ordered operands of a binary operator. Unary operators use operand;
	// Function calls use their own signature.
	operands?: null | list.MaxItems(2) & [...#Expression & #Expression] & [_, _, ...]
	operator?: #Operator

	// Numerical literal with an explicit magnitude and units, independent of any
	// Measure. Use dimensionless for unitless content. Zero is a literal, not
	// absence.
	quantity?: #Quantity & matchN(>=1, [#Quantity, null])
	query?: #Query & matchN(>=1, [#Query, null])
	selection?: #Selection & matchN(>=1, [#Selection, null])

	// Value symbol referenced by its stable UUID in the applicable Model or
	// composed Specification scope.
	target?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// ExpressionKind
#ExpressionKind: "quantity" | "boolean" | "reference" | "unary" | "binary" | "call" | "selection" | "query"

// Filter
//
// Conjunctive filters over fixed Entity metadata. No numerical expression or
// solved amount determines membership.
#Filter: close({
	classification?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// All listed Label conditions must hold.
	labels?: null | [...#Criterion & #Criterion]
})

// Function
//
// An identified, versioned contract for a pure mathematical or domain function,
// independent of a particular runtime implementation.
#Function: close({
	code!: string

	// Required for functions with collection arguments. Zero is permitted only when
	// the result domain and units can be established without reading a member.
	empty_collection?: #EmptyHandling
	id!:               =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable function name.
	name!: string & =~"\\S"

	// Ordered signature. Omission denotes no parameters.
	parameters?: null | [...#Parameter & #Parameter]

	// Domain of the result.
	result!: #Domain & #Domain

	// Mathematical meaning, argument conventions, domain restrictions, and exceptional cases.
	semantics!: string & =~"\\S"

	// How result units follow from the arguments, or why units do not apply. This
	// rule requires semantic implementation; prose is not an executable unit
	// checker.
	unit_rule!: string & =~"\\S"
	version!:   string
})

// Label
//
// A named set of Classifications describing an aspect of an Entity or Relationship.
#Label: close({
	// Unique UUID references to Classifications describing this aspect.
	classifications?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Stable identity of the Label, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Name unique within the owner's characteristics.labels collection.
	key!: =~"\\S"
})

// Measure
//
// An identified definition of a measurable characteristic and its canonical units.
#Measure: close({
	// Case-sensitive code unique within the Model’s Measure collection; not reference identity.
	code!: string

	// Optional explanatory text describing the measurement convention.
	definition?: null | string

	// Stable identity of this Measure definition.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name of the measured characteristic.
	name!: =~"\\S"

	// Unordered, nonblank descriptive terms, with no duplicates.
	tags?: null | [...=~"\\S"]

	// Nonblank expression specifying the canonical units for quantities interpreted
	// through this Measure, such as m^2 or AUD/year. Unitless quantities must have
	// an explicit dimensionless convention.
	units!: =~"\\S"
})

// Measurement
//
// An identified measurable property with a Measure and an optional Quantity.
#Measurement: close({
	// Stable identity of the Measurement, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// Metadata
//
// Identity, description, and optional lineage of one immutable document revision.
#Metadata: close({
	// Optional explanation of this revision and its purpose.
	description?: null | string

	// UUID identifying the enclosing immutable document revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional human-readable name of this revision.
	name?: null | =~"\\S"

	// UUID of the preceding revision of the same document kind, referencing its Metadata.
	previous?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Version of the enclosing document's schema contract.
	schema_version!: string
})

// MissingHandling
#MissingHandling: "error" | "omit"

// Operator
#Operator: "add" | "subtract" | "multiply" | "divide" | "equal" | "not_equal" | "less_than" | "less_than_or_equal" | "greater_than" | "greater_than_or_equal" | "power" | "negate" | "logical_not" | "logical_and" | "logical_or"

// Parameter
//
// A named argument in a Function signature. List order determines positional argument order.
#Parameter: close({
	// Content permitted for this argument.
	domain!: #Domain & #Domain

	// How a call may supply this parameter.
	kind!: #ParameterKind
	name!: string

	// Whether a call must supply this argument.
	required!: bool & bool
})

// ParameterKind
#ParameterKind: "positional_or_named" | "named_only"

// Projection
//
// Select Entity identities or Values belonging to each matching Entity.
#Projection: matchN(2, [matchIf({
	kind!: "entity"
	...
}, matchN(4, [matchN(0, [null | bool | number | string | [...] | {
	key!: _
	...
}]) & {
	key?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	measure!: _
	...
}]) & {
	measure?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	cardinality!: _
	...
}]) & {
	cardinality?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	missing!: _
	...
}]) & {
	missing?: _
	...
}]), _) & {
	...
}, matchIf({
	kind!: "value"
	...
}, matchN(1, [{
	key!: _
	...
}, {
	measure!: _
	...
}]) & {
	cardinality!: _
	missing!:     _
	...
}, _) & {
	...
}]) & close({
	cardinality?: #Cardinality

	// Exact owner-local Value key.
	key?:  string & =~"\\S"
	kind!: #ProjectionKind

	// Select Values with this exact Measure.
	measure?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	missing?: #MissingHandling
})

// ProjectionKind
#ProjectionKind: "entity" | "value"

// Quantity
//
// Numerical content consisting of a finite magnitude and explicit units.
#Quantity: close({
	// Finite numerical magnitude expressed in the accompanying units.
	magnitude!: number

	// Explicit units for this magnitude, such as m^2, AUD/year, or dimensionless.
	units!: =~"\\S"
})

// Query
//
// A non-executing query specification returning Entity or Value identities from
// the containing Model revision.
#Query: close({
	duplicates!: #DuplicateHandling
	filter?: #Filter & matchN(>=1, [#Filter, null])
	projection!:  #Projection & #Projection
	starting_at!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Ordered traversal steps; omission selects the starting Entity.
	steps?: null | [...#Traversal & #Traversal]
})

// Relationship
//
// An identified, directed connection from one Entity to another. Its
// classification describes the connection; its characteristics describe
// properties of the connection itself.
#Relationship: close({
	// Labels and Values describing this connection.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Stable identity of the Relationship across Model revisions.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// UUID of the source Entity.
	source!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// UUID of the target Entity.
	target!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Selection
//
// Read a declared member or indexed element from structured expression content.
#Selection: matchN(2, [matchIf({
	kind!: "member"
	...
}, matchN(0, [null | bool | number | string | [...] | {
	index!: _
	...
}]) & {
	index?: _
	...
} & {
	member!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "index"
	...
}, matchN(0, [null | bool | number | string | [...] | {
	member!: _
	...
}]) & {
	member?: _
	...
} & {
	index!: _
	...
}, _) & {
	...
}]) & close({
	base!: #Expression & #Expression

	// Index expression.
	index?: #Expression & matchN(>=1, [#Expression, null])
	kind!: #SelectionKind

	// Declared member name.
	member?: null | string
})

// SelectionKind
#SelectionKind: "member" | "index"

// Taxonomy
//
// A named, single-root hierarchy of Classifications.
#Taxonomy: close({
	// Identified Classifications belonging to this Taxonomy; codes are unique within the collection.
	classifications!: [...#Classification] & [_, ...]

	// Case-sensitive code unique in the Model's taxonomy catalogue.
	code!:       string
	definition?: null | string
	id!:         =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	name!:       =~"\\S"
})

// Traversal
//
// One traversal step over domain Relationships or Assembly membership.
#Traversal: matchN(2, [matchIf({
	kind!: "relationship"
	...
}, {
	classification!: _
	direction!:      _
	...
}, _) & {
	...
}, matchIf({
	kind!: "membership"
	...
}, matchN(2, [matchN(0, [null | bool | number | string | [...] | {
	classification!: _
	...
}]) & {
	classification?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	direction!: _
	...
}]) & {
	direction?: _
	...
}]), _) & {
	...
}]) & close({
	// Exact Classification of Relationships to follow.
	classification?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	depth!:          #Depth
	direction?:      #Direction
	kind!:           #TraversalKind
})

// TraversalKind
#TraversalKind: "relationship" | "membership"

// Value
//
// An identified, typed Value belonging to an Entity or Relationship's
// Characteristics, or declared locally within a mathematical Formulation. Its
// key provides a name within the owner's values collection; its UUID
// identifies the symbol independently of that name.
#Value: close({
	// Explanation of the meaning of this Value within its owner.
	description?: null | string

	// Stable identity of the Value, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank name unique within the owner's values collection; not reference identity.
	key!: =~"\\S"

	// The kind of content represented by this characteristic.
	kind!: #ValueKind

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// ValueKind
//
// Supported kinds of Values.
#ValueKind: "measurement"

// rangekeeper_classification
//
// A named definition node in a taxonomy hierarchy.
package comparison

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")
@jsonschema(id="https://daniel-fink.github.io/rangekeeper/schema/classification")
close({
	// Case-sensitive code unique within its Taxonomy; descriptive metadata, not reference identity.
	code!: string

	// Optional explanatory text; an empty string is permitted.
	definition?: null | string

	// Stable identity across code changes and Model revisions.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name.
	name!: =~"\\S"

	// Parent Classification in the same Taxonomy, referenced by UUID. An absent or
	// null parent denotes a root candidate.
	parent?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Classification
//
// A named definition node in a taxonomy hierarchy.
#Classification: close({
	// Case-sensitive code unique within its Taxonomy; descriptive metadata, not reference identity.
	code!: string

	// Optional explanatory text; an empty string is permitted.
	definition?: null | string

	// Stable identity across code changes and Model revisions.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name.
	name!: =~"\\S"

	// Parent Classification in the same Taxonomy, referenced by UUID. An absent or
	// null parent denotes a root candidate.
	parent?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Metadata
//
// Identity, description, and optional lineage of one immutable document revision.
#Metadata: close({
	// Optional explanation of this revision and its purpose.
	description?: null | string

	// UUID identifying the enclosing immutable document revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional human-readable name of this revision.
	name?: null | =~"\\S"

	// UUID of the preceding revision of the same document kind, referencing its Metadata.
	previous?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Version of the enclosing document's schema contract.
	schema_version!: string
})

// Taxonomy
//
// A named, single-root hierarchy of Classifications.
#Taxonomy: close({
	// Identified Classifications belonging to this Taxonomy; codes are unique within the collection.
	classifications!: [...#Classification] & [_, ...]

	// Case-sensitive code unique in the Model's taxonomy catalogue.
	code!:       string
	definition?: null | string
	id!:         =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	name!:       =~"\\S"
})

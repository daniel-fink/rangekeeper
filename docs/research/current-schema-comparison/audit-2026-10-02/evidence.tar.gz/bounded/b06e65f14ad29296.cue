// rangekeeper_measure
//
// An identified definition of a measurable characteristic and its canonical units.
package comparison

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")
@jsonschema(id="https://daniel-fink.github.io/rangekeeper/schema/measure")
close({
	// Case-sensitive code unique within the Model’s Measure collection; not reference identity.
	code!: string

	// Optional explanatory text describing the measurement convention.
	definition?: null | string

	// Stable identity of this Measure definition.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name of the measured characteristic.
	name!: =~"\\S"

	// Unordered, nonblank descriptive terms, with no duplicates.
	tags?: null | [...=~"\\S"]

	// Nonblank expression specifying the canonical units for quantities interpreted
	// through this Measure, such as m^2 or AUD/year. Unitless quantities must have
	// an explicit dimensionless convention.
	units!: =~"\\S"
})

// Measure
//
// An identified definition of a measurable characteristic and its canonical units.
#Measure: close({
	// Case-sensitive code unique within the Model’s Measure collection; not reference identity.
	code!: string

	// Optional explanatory text describing the measurement convention.
	definition?: null | string

	// Stable identity of this Measure definition.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name of the measured characteristic.
	name!: =~"\\S"

	// Unordered, nonblank descriptive terms, with no duplicates.
	tags?: null | [...=~"\\S"]

	// Nonblank expression specifying the canonical units for quantities interpreted
	// through this Measure, such as m^2 or AUD/year. Unitless quantities must have
	// an explicit dimensionless convention.
	units!: =~"\\S"
})

// Measurement
//
// An identified measurable property with a Measure and an optional Quantity.
#Measurement: close({
	// Stable identity of the Measurement, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// Metadata
//
// Identity, description, and optional lineage of one immutable document revision.
#Metadata: close({
	// Optional explanation of this revision and its purpose.
	description?: null | string

	// UUID identifying the enclosing immutable document revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional human-readable name of this revision.
	name?: null | =~"\\S"

	// UUID of the preceding revision of the same document kind, referencing its Metadata.
	previous?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Version of the enclosing document's schema contract.
	schema_version!: string
})

// Quantity
//
// Numerical content consisting of a finite magnitude and explicit units.
#Quantity: close({
	// Finite numerical magnitude expressed in the accompanying units.
	magnitude!: number

	// Explicit units for this magnitude, such as m^2, AUD/year, or dimensionless.
	units!: =~"\\S"
})

// rangekeeper_function
//
// An identified, versioned contract for a pure mathematical or domain function,
// independent of a particular runtime implementation.
package comparison

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")
@jsonschema(id="https://daniel-fink.github.io/rangekeeper/schema/function")
close({
	code!: string

	// Required for functions with collection arguments. Zero is permitted only when
	// the result domain and units can be established without reading a member.
	empty_collection?: #EmptyHandling
	id!:               =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable function name.
	name!: string & =~"\\S"

	// Ordered signature. Omission denotes no parameters.
	parameters?: null | [...#Parameter & #Parameter]

	// Domain of the result.
	result!: #Domain & #Domain

	// Mathematical meaning, argument conventions, domain restrictions, and exceptional cases.
	semantics!: string & =~"\\S"

	// How result units follow from the arguments, or why units do not apply. This
	// rule requires semantic implementation; prose is not an executable unit
	// checker.
	unit_rule!: string & =~"\\S"
	version!:   string
})

// CollectionKind
#CollectionKind: "set" | "bag" | "sequence"

// Domain
//
// The permitted content of an argument or result, including its kind,
// compatible units, measurement meaning, and collection elements where
// applicable.
#Domain: matchN(4, [matchIf({
	kind!: "collection"
	...
}, {
	item_domain!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "number" | "quantity" | "measurement" | "boolean" | "string" | "date" | "span" | "flow" | "stream" | "account" | "entity"
	...
}, matchN(2, [matchN(0, [null | bool | number | string | [...] | {
	item_domain!: _
	...
}]) & {
	item_domain?: _
	...
}, matchN(0, [null | bool | number | string | [...] | {
	collection_kind!: _
	...
}]) & {
	collection_kind?: _
	...
}]), _) & {
	...
}, matchIf({
	kind!: "number" | "quantity" | "boolean" | "string" | "date" | "span" | "stream" | "account" | "entity" | "collection"
	...
}, matchN(0, [null | bool | number | string | [...] | {
	measure!: _
	...
}]) & {
	measure?: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "number" | "measurement" | "boolean" | "string" | "date" | "span" | "flow" | "stream" | "account" | "entity" | "collection"
	...
}, matchN(0, [null | bool | number | string | [...] | {
	units!: _
	...
}]) & {
	units?: _
	...
}, _) & {
	...
}]) & close({
	// Optional collection shape required by this signature.
	collection_kind?: #CollectionKind

	// Domain of each collection element.
	item_domain?: #Domain & matchN(>=1, [#Domain, null])

	// The category of content permitted by this Domain.
	kind!: #DomainKind

	// Optional exact measurement meaning required for a measurement or Flow.
	measure?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional compatible units required for Quantity content. Omission leaves
	// units unconstrained by the signature; a concrete Quantity still requires
	// explicit units.
	units?: null | =~"\\S"
})

// DomainKind
#DomainKind: "number" | "quantity" | "measurement" | "boolean" | "string" | "date" | "span" | "flow" | "stream" | "account" | "entity" | "collection"

// EmptyHandling
#EmptyHandling: "error" | "zero"

// Function
//
// An identified, versioned contract for a pure mathematical or domain function,
// independent of a particular runtime implementation.
#Function: close({
	code!: string

	// Required for functions with collection arguments. Zero is permitted only when
	// the result domain and units can be established without reading a member.
	empty_collection?: #EmptyHandling
	id!:               =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable function name.
	name!: string & =~"\\S"

	// Ordered signature. Omission denotes no parameters.
	parameters?: null | [...#Parameter & #Parameter]

	// Domain of the result.
	result!: #Domain & #Domain

	// Mathematical meaning, argument conventions, domain restrictions, and exceptional cases.
	semantics!: string & =~"\\S"

	// How result units follow from the arguments, or why units do not apply. This
	// rule requires semantic implementation; prose is not an executable unit
	// checker.
	unit_rule!: string & =~"\\S"
	version!:   string
})

// Measure
//
// An identified definition of a measurable characteristic and its canonical units.
#Measure: close({
	// Case-sensitive code unique within the Model’s Measure collection; not reference identity.
	code!: string

	// Optional explanatory text describing the measurement convention.
	definition?: null | string

	// Stable identity of this Measure definition.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name of the measured characteristic.
	name!: =~"\\S"

	// Unordered, nonblank descriptive terms, with no duplicates.
	tags?: null | [...=~"\\S"]

	// Nonblank expression specifying the canonical units for quantities interpreted
	// through this Measure, such as m^2 or AUD/year. Unitless quantities must have
	// an explicit dimensionless convention.
	units!: =~"\\S"
})

// Measurement
//
// An identified measurable property with a Measure and an optional Quantity.
#Measurement: close({
	// Stable identity of the Measurement, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// Metadata
//
// Identity, description, and optional lineage of one immutable document revision.
#Metadata: close({
	// Optional explanation of this revision and its purpose.
	description?: null | string

	// UUID identifying the enclosing immutable document revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional human-readable name of this revision.
	name?: null | =~"\\S"

	// UUID of the preceding revision of the same document kind, referencing its Metadata.
	previous?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Version of the enclosing document's schema contract.
	schema_version!: string
})

// Parameter
//
// A named argument in a Function signature. List order determines positional argument order.
#Parameter: close({
	// Content permitted for this argument.
	domain!: #Domain & #Domain

	// How a call may supply this parameter.
	kind!: #ParameterKind
	name!: string

	// Whether a call must supply this argument.
	required!: bool & bool
})

// ParameterKind
#ParameterKind: "positional_or_named" | "named_only"

// Quantity
//
// Numerical content consisting of a finite magnitude and explicit units.
#Quantity: close({
	// Finite numerical magnitude expressed in the accompanying units.
	magnitude!: number

	// Explicit units for this magnitude, such as m^2, AUD/year, or dimensionless.
	units!: =~"\\S"
})

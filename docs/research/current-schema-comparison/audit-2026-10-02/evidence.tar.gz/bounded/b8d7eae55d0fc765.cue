// rangekeeper_provenance
//
// Facts connecting graph objects to supporting Claims, with the Sources and
// upstream Claims needed to follow their lineage.
package comparison

import "time"

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")
@jsonschema(id="https://daniel-fink.github.io/rangekeeper/schema/provenance")
close({
	claims?: null | [...#Claim]
	facts?: null | [...#Fact]
	sources?: null | [...#Source]
})

// Assembly
//
// An Entity identifying a collection of Entities and Relationships. Members are
// referenced by identity and may belong to more than one Assembly. Membership
// does not imply spatial containment or duplicate its members.
#Assembly: close({
	// The Entity's labels and named values.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional case-sensitive code unique among all Entities and Assemblies in the
	// Model. Renaming it preserves UUID identity and references.
	code?: null | string

	// Unordered, unique UUIDs of member Entities, including nested Assemblies.
	entities?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Stable identity of the Entity, distinct from a Model revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable display name; not used as identity.
	name?: null | =~"\\S"

	// Unordered, unique UUIDs of member Relationships.
	relationships?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]
})

// Characteristics
//
// A collection of Labels and Values belonging to an Entity or Relationship.
// Each Label or Value has a stable UUID and a key unique within its
// collection.
#Characteristics: close({
	// Identified labels with explicit owner-local keys, unique within this collection.
	labels?: null | [...#Label]

	// Identified values with explicit owner-local keys, unique within this collection.
	values?: null | [...#Value]
})

// Claim
//
// Sourced, asserted, or derived candidate content and its supporting lineage.
#Claim: matchN(2, [matchIf({
	kind!: "asserted" | "derived"
	...
}, {
	method!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "sourced" | "derived"
	...
}, {
	sources!: _
	...
}, _) & {
	...
}]) & close({
	content!: #Content
	id!:      =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	kind!:    #ClaimKind
	method?: matchN(>=1, [#Method, null])

	// Source Locations or UUID references to upstream Claims.
	sources?: null | [...#Content & matchN(>=1, [#Location, =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"])]
})

// ClaimKind
#ClaimKind: "sourced" | "asserted" | "derived"

// Classification
//
// A named definition node in a taxonomy hierarchy.
#Classification: close({
	// Case-sensitive code unique within its Taxonomy; descriptive metadata, not reference identity.
	code!: string

	// Optional explanatory text; an empty string is permitted.
	definition?: null | string

	// Stable identity across code changes and Model revisions.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name.
	name!: =~"\\S"

	// Parent Classification in the same Taxonomy, referenced by UUID. An absent or
	// null parent denotes a root candidate.
	parent?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Content
//
// Candidate content whose structure and meaning depend on the supported target.
// Content must be validated against that target before a Fact is accepted;
// this generic envelope does not make arbitrary content executable.
#Content: null | bool | number | string | {
	...
}

// Entity
//
// An identifiable domain object, such as an apartment, building, or actor. Its
// identity persists across immutable Model revisions. Loading its definition
// does not execute calculations.
#Entity: close({
	// The Entity's labels and named values.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional case-sensitive code unique among all Entities and Assemblies in the
	// Model. Renaming it preserves UUID identity and references.
	code?: null | string

	// Stable identity of the Entity, distinct from a Model revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Human-readable display name; not used as identity.
	name?: null | =~"\\S"
})

// Entry
//
// A named text component of a source address.
#Entry: close({
	key!:   =~"\\S"
	value!: =~"\\S"
})

// Entry
//
// A named text component of a source address.
#Entry__identifier_optional: close({
	key?:   =~"\\S"
	value!: =~"\\S"
})

// Fact
//
// Supporting Claims for the recorded state of one graph object or characteristic.
#Fact: close({
	// Unique UUIDs of supporting Claims; at least one is required.
	claims!: [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"] & [_, ...]
	reconciliation?: matchN(>=1, [#Reconciliation, null])

	// The actual graph object or characteristic being supported, referenced by its stable UUID.
	target!: #Content & matchN(>=1, [=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"])
})

// Label
//
// A named set of Classifications describing an aspect of an Entity or Relationship.
#Label: close({
	// Unique UUID references to Classifications describing this aspect.
	classifications?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Stable identity of the Label, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Name unique within the owner's characteristics.labels collection.
	key!: =~"\\S"
})

// Location
//
// An address within a specific Source edition.
#Location: close({
	// Named address parts, such as sheet and cell, with nonblank text values.
	address?: null | {
		[string]: matchN(>=1, [#Entry__identifier_optional, =~"\\S"])
	}
	source!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Measure
//
// An identified definition of a measurable characteristic and its canonical units.
#Measure: close({
	// Case-sensitive code unique within the Model’s Measure collection; not reference identity.
	code!: string

	// Optional explanatory text describing the measurement convention.
	definition?: null | string

	// Stable identity of this Measure definition.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name of the measured characteristic.
	name!: =~"\\S"

	// Unordered, nonblank descriptive terms, with no duplicates.
	tags?: null | [...=~"\\S"]

	// Nonblank expression specifying the canonical units for quantities interpreted
	// through this Measure, such as m^2 or AUD/year. Unitless quantities must have
	// an explicit dimensionless convention.
	units!: =~"\\S"
})

// Measurement
//
// An identified measurable property with a Measure and an optional Quantity.
#Measurement: close({
	// Stable identity of the Measurement, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// Metadata
//
// Identity, description, and optional lineage of one immutable document revision.
#Metadata: close({
	// Optional explanation of this revision and its purpose.
	description?: null | string

	// UUID identifying the enclosing immutable document revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional human-readable name of this revision.
	name?: null | =~"\\S"

	// UUID of the preceding revision of the same document kind, referencing its Metadata.
	previous?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Version of the enclosing document's schema contract.
	schema_version!: string
})

// Method
//
// The named process used to assert, derive, or reconcile evidence.
#Method: close({
	code!:        =~"\\S"
	description?: null | =~"\\S"
	version?:     null | =~"\\S"
})

// Provenance
//
// Facts connecting graph objects to supporting Claims, with the Sources and
// upstream Claims needed to follow their lineage.
#Provenance: close({
	claims?: null | [...#Claim]
	facts?: null | [...#Fact]
	sources?: null | [...#Source]
})

// Quantity
//
// Numerical content consisting of a finite magnitude and explicit units.
#Quantity: close({
	// Finite numerical magnitude expressed in the accompanying units.
	magnitude!: number

	// Explicit units for this magnitude, such as m^2, AUD/year, or dimensionless.
	units!: =~"\\S"
})

// Reconciliation
//
// Explicit selection of one supporting Claim when evidence conflicts.
#Reconciliation: close({
	method?: matchN(>=1, [#Method, null])

	// UUID of a Claim included in the Fact's claims.
	selected!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	status!:   #ReconciliationStatus
})

// ReconciliationStatus
#ReconciliationStatus: "provisional" | "confirmed"

// Relationship
//
// An identified, directed connection from one Entity to another. Its
// classification describes the connection; its characteristics describe
// properties of the connection itself.
#Relationship: close({
	// Labels and Values describing this connection.
	characteristics?: matchN(>=1, [#Characteristics, null])

	// Classification describing the object, referenced by its stable UUID.
	classification!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Stable identity of the Relationship across Model revisions.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// UUID of the source Entity.
	source!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// UUID of the target Entity.
	target!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Source
//
// An identifiable edition of an external evidence artifact.
#Source: close({
	author?: null | =~"\\S"

	// Content checksum identifying the evidence edition.
	checksum!: =~"\\S"
	id!:       =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	issued_at?: matchN(>=1, [time.Format("2006-01-02"), time.Time, null])
	name!: =~"\\S"
	received_at?: matchN(>=1, [time.Format("2006-01-02"), time.Time, null])
})

// Taxonomy
//
// A named, single-root hierarchy of Classifications.
#Taxonomy: close({
	// Identified Classifications belonging to this Taxonomy; codes are unique within the collection.
	classifications!: [...#Classification] & [_, ...]

	// Case-sensitive code unique in the Model's taxonomy catalogue.
	code!:       string
	definition?: null | string
	id!:         =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
	name!:       =~"\\S"
})

// Value
//
// An identified, typed Value belonging to an Entity or Relationship's
// Characteristics, or declared locally within a mathematical Formulation. Its
// key provides a name within the owner's values collection; its UUID
// identifies the symbol independently of that name.
#Value: close({
	// Explanation of the meaning of this Value within its owner.
	description?: null | string

	// Stable identity of the Value, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank name unique within the owner's values collection; not reference identity.
	key!: =~"\\S"

	// The kind of content represented by this characteristic.
	kind!: #ValueKind

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// ValueKind
//
// Supported kinds of Values.
#ValueKind: "measurement"

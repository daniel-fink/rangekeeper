// rangekeeper_run
//
// The finalized record of one execution attempt against an exact Specification revision.
package comparison

import "time"

@jsonschema(schema="https://json-schema.org/draft/2019-09/schema")
@jsonschema(id="https://daniel-fink.github.io/rangekeeper/schema/run")
close({
	// Identity and schema version of this immutable Run record.
	metadata!: #Metadata & #Metadata

	// Unique accepted output Model revision references, or their union for a batch.
	outputs?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Execution outcome and supporting evidence.
	report!: #Report & #Report

	// Unique references to directly spawned Run revisions.
	spawns?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Exact attempted Specification revision, resolved as a Specification document.
	specification!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// CompletionStatus
#CompletionStatus: "completed" | "limited" | "partial" | "failed" | "cancelled" | "skipped"

// Diagnostic
//
// A coded finding and optional numerical evidence, qualified by document revision.
#Diagnostic: matchN(3, [matchIf({
	target!: _
	...
}, {
	document!: _
	...
}, _) & {
	...
}, matchIf({
	residual!: _
	...
}, {
	document!: _
	target!:   _
	...
}, _) & {
	...
}, matchIf({
	tolerance!: _
	...
}, {
	residual!: _
	...
}, _) & {
	...
}]) & close({
	// Nonblank finding code.
	code!: string

	// Revision containing the referenced target, or the document addressed as a whole.
	document?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Explanation and, for numerical findings, the checking convention.
	message!: =~"\\S"

	// Finite signed residual under the stated convention.
	residual?: #Quantity & matchN(>=1, [#Quantity, null])

	// Importance of the finding.
	severity!: #Severity

	// UUID of a canonical record in document; never an unqualified cross-revision reference.
	target?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Finite nonnegative tolerance in compatible units.
	tolerance?: #Quantity & matchN(>=1, [#Quantity, null])
})

// Implementation
//
// An implementation role and its reproducible software identity as reported for this execution.
#Implementation: close({
	// Role performed by the implementation.
	kind!: #ImplementationKind

	// Nonblank implementation name.
	name!: =~"\\S"

	// Nonblank version or immutable build identifier.
	version!: =~"\\S"
})

// ImplementationKind
#ImplementationKind: "evaluator" | "compiler" | "solver"

// Measure
//
// An identified definition of a measurable characteristic and its canonical units.
#Measure: close({
	// Case-sensitive code unique within the Model’s Measure collection; not reference identity.
	code!: string

	// Optional explanatory text describing the measurement convention.
	definition?: null | string

	// Stable identity of this Measure definition.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Nonblank human-readable name of the measured characteristic.
	name!: =~"\\S"

	// Unordered, nonblank descriptive terms, with no duplicates.
	tags?: null | [...=~"\\S"]

	// Nonblank expression specifying the canonical units for quantities interpreted
	// through this Measure, such as m^2 or AUD/year. Unitless quantities must have
	// an explicit dimensionless convention.
	units!: =~"\\S"
})

// Measurement
//
// An identified measurable property with a Measure and an optional Quantity.
#Measurement: close({
	// Stable identity of the Measurement, used by provenance Facts.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Measure defining meaning and canonical units, referenced by its stable UUID.
	measure!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional recorded numerical content. Its units must be compatible with the
	// Measure's canonical units. Omission or null denotes unresolved content.
	quantity?: matchN(>=1, [#Quantity, null])
})

// Metadata
//
// Identity, description, and optional lineage of one immutable document revision.
#Metadata: close({
	// Optional explanation of this revision and its purpose.
	description?: null | string

	// UUID identifying the enclosing immutable document revision.
	id!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Optional human-readable name of this revision.
	name?: null | =~"\\S"

	// UUID of the preceding revision of the same document kind, referencing its Metadata.
	previous?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Version of the enclosing document's schema contract.
	schema_version!: string
})

// Quantity
//
// Numerical content consisting of a finite magnitude and explicit units.
#Quantity: close({
	// Finite numerical magnitude expressed in the accompanying units.
	magnitude!: number

	// Explicit units for this magnitude, such as m^2, AUD/year, or dimensionless.
	units!: =~"\\S"
})

// Report
//
// Outcome, actual runtime, findings, and ordered execution trace of a Run.
#Report: close({
	// Unordered findings supporting interpretation of the outcome.
	diagnostics?: null | [...#Diagnostic]

	// Actual runtime when known; may be absent for a skipped or pre-execution failure.
	runtime?: #Runtime & matchN(>=1, [#Runtime, null])

	// Required execution and mathematical outcome.
	status!: #Status & #Status

	// Ordered execution and selection records; list order is preserved.
	trace?: null | [...#Step]
})

// Run
//
// The finalized record of one execution attempt against an exact Specification revision.
#Run: close({
	// Identity and schema version of this immutable Run record.
	metadata!: #Metadata & #Metadata

	// Unique accepted output Model revision references, or their union for a batch.
	outputs?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Execution outcome and supporting evidence.
	report!: #Report & #Report

	// Unique references to directly spawned Run revisions.
	spawns?: null | [...=~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"]

	// Exact attempted Specification revision, resolved as a Specification document.
	specification!: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// Runtime
//
// Observed timing, implementation identities, and effective numerical settings.
#Runtime: close({
	// Observed finish instant with an explicit timezone.
	finished_at?: null | time.Time

	// Actual implementation identities; nonempty when Runtime is present.
	implementations!: [...#Implementation] & [_, ...]

	// Effective numerical settings, rather than merely copied requests.
	settings?: #Settings & matchN(>=1, [#Settings, null])

	// Observed start instant with an explicit timezone.
	started_at?: null | time.Time
})

// Settings
//
// Numerical convergence and resource settings; the containing record
// distinguishes requested from effective values.
#Settings: close({
	// Maximum number of solver iterations requested, interpreted by the backend's documented algorithm.
	iteration_limit?: null | int & >=1

	// Positive finite dimensionless convergence tolerance, strictly less than one.
	relative_tolerance?: null | <=1 & >=0

	// Positive finite execution time limit in seconds, using the backend's
	// documented timing convention.
	time_limit?: null | >=0
})

// Severity
#Severity: "info" | "warning" | "error"

// SolutionStatus
#SolutionStatus: "feasible" | "infeasible" | "unknown" | "not_assessed" | "not_applicable"

// Status
//
// Execution completion and mathematical conclusion, recorded independently.
#Status: close({
	// How this attempt ended, or the aggregate completion of a batch.
	completion!: #CompletionStatus

	// Mathematical conclusion; batches use not_applicable.
	solution!: #SolutionStatus
})

// Step
//
// One ordered record of execution activity, without prescribing scheduling or policy logic.
#Step: matchN(2, [matchIf({
	target!: _
	...
}, {
	document!: _
	...
}, _) & {
	...
}, matchIf({
	kind!: "publication" | "selection"
	...
}, {
	document!: _
	...
}, _) & {
	...
}]) & close({
	// Observed event instant with an explicit timezone.
	at?: null | time.Time

	// Revision containing the referenced target, or the document addressed as a whole.
	document?: =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$" & =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"

	// Kind of recorded execution activity.
	kind!: #StepKind

	// What occurred and the basis for any selection.
	message!: =~"\\S"

	// UUID of a canonical record in document; never an unqualified cross-revision reference.
	target?: null | =~"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
})

// StepKind
#StepKind: "validation" | "formulation" | "solve" | "publication" | "selection"
